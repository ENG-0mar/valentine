
import { GoogleGenAI } from "@google/genai";

/**
 * Generates a romantic compliment using the Gemini API.
 * Uses gemini-3-flash-preview for this basic text generation task.
 */
export const generateCompliment = async (): Promise<string> => {
  try {
    // Always initialize the client within the function to use the latest API key from process.env.API_KEY
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate a single, short, incredibly sweet and unique romantic compliment for a girlfriend on Valentine's Day. Keep it under 20 words.",
      config: {
        temperature: 0.9,
      },
    });

    // Directly access the .text property from the response as per Gemini SDK guidelines
    return response.text?.trim() || "You are the best thing that ever happened to me.";
  } catch (error) {
    console.error("Gemini error:", error);
    return "Your love is the sunshine in my life.";
  }
};
