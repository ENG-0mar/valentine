
import React from 'react';
import { motion } from 'framer-motion';

interface Props {
  onStart: () => void;
}

const IntroStep: React.FC<Props> = ({ onStart }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
        className="text-center max-w-2xl w-full z-10"
      >
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", damping: 12, delay: 0.3 }}
          className="mb-10 inline-flex items-center justify-center w-28 h-28 rounded-full bg-white/40 glass-card"
        >
          <span className="text-5xl animate-bounce" style={{ animationDuration: '3s' }}>❤️</span>
        </motion.div>
        
        <h1 className="text-6xl md:text-8xl font-arabic-romance text-rose-600 mb-8 leading-tight drop-shadow-sm">
         جهزي نفسك يروح قلبي
        </h1>
      

        <motion.button
          whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(244,63,94,0.25)" }}
          whileTap={{ scale: 0.95 }}
          onClick={onStart}
          className="group relative px-16 py-6 bg-rose-500 text-white rounded-full font-bold text-2xl shadow-xl transition-all duration-500 overflow-hidden"
        >
          <span className="relative z-10 flex items-center justify-center gap-3">
           Let's start baby ❤️
          </span>
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-rose-400 to-rose-600 opacity-0 group-hover:opacity-100 transition-opacity"
          />
        </motion.button>
        
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ delay: 2 }}
          className="mt-12 text-rose-300 text-sm font-light italic"
        >
         Kisses for uuuuuuuuuuuuu
        </motion.p>
      </motion.div>
    </div>
  );
};

export default IntroStep;
