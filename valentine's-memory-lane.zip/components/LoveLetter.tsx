
import React from 'react';

const LoveLetter: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto py-16 px-4">
      <div className="bg-[#fff9f0] p-10 md:p-16 rounded-sm shadow-xl border-l-8 border-red-400 relative overflow-hidden">
        <div className="absolute top-4 right-4 opacity-10">
          <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
          </svg>
        </div>
        
        <h3 className="text-3xl font-cursive text-red-600 mb-8">My girl My Whole world My Jojo..Jomana</h3>
        
        <div className="space-y-6 text-gray-800 text-lg leading-relaxed font-light italic">
          <p>
           انا نفسي اعبرلك عن قد ايه انا بحبك بس حقيقي مش لاقي كلمه توصف حبي ليكي مش لاقي حاجه توصف انت غاليه عندي قد ايه مش متخيله حياتي بوجودك عامله ازاي 
          </p>
          <p>
            انا حقيقي مقدرش اعيش من غيرك انت مصدر طاقتي و مصدر فرحتي و مصدر كل حاجه حلوه فحياتي 
وقوفك جمبي و فضهري و حبك ليا و كل حاجه بتعمليها انت مش متخيله بتخليني فرحان و مبسوط ازاي مش متخيله إحساسي عامل ازاي اني معايا احلى بنت فالدنيا 
          </p>
          <p>
           انت فعلا يجومانه ولله احلى بنت فالدنيا عمر م في بنت هتعرف توصل لجمالك و جمال شخصيتك و جمال كل حاجه فيكي انت ولله احلى و اجمل و اغلى ما عندي 
بحبك يجومانه بحبك اوي بعشقك و ولله بقولها من كل قلبي انا بعشقك♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️
          </p>
          <p className="pt-8">
            Your man,
          </p>
          <p className="text-2xl font-cursive text-red-600">
            [Mora]
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoveLetter;
