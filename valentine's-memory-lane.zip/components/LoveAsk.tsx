
import React from 'react';
import { motion } from 'framer-motion';

interface Props {
  onAccept: () => void;
}

const LoveAsk: React.FC<Props> = ({ onAccept }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="text-center z-10 glass-card p-12 md:p-16 rounded-[4rem] max-w-xl w-full border border-white"
      >
        <img 
          src="https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExNm5uN3p0cWh1a2VmcWhjOTFkbmdqdmJsYWJtdXFiMGsydTNoajdpYyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/Tld8USHlpopYA/giphy.gif" 
          alt="Love"
          className="w-48 h-48 mx-auto mb-10 rounded-3xl shadow-lg"
        />
        <h1 className="text-5xl md:text-6xl font-arabic-romance text-rose-600 mb-10 leading-tight">
         ويت اخر حاجه <br/> بتحبيني؟
        </h1>
        
        <div className="flex flex-col sm:flex-row gap-6 justify-center">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onAccept}
            className="bg-rose-500 hover:bg-rose-600 text-white font-bold py-5 px-14 rounded-full shadow-xl shadow-rose-200 transition-all text-xl"
          >
           بموت فيك
          </motion.button>
          
          <button
            className="bg-gray-100 text-gray-400 font-bold py-5 px-14 rounded-full cursor-not-allowed opacity-40 border border-gray-200"
            disabled
          >
            لأ
          </button>
        </div>
        <p className="mt-8 text-rose-300 italic font-light">خدتي بالك ال لأ مش شغال </p>
      </motion.div>
    </div>
  );
};

export default LoveAsk;
