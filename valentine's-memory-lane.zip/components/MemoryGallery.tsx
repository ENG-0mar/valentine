
import React from 'react';
import { motion } from 'framer-motion';
import { MEMORIES } from '../constants';

const MemoryGallery: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto py-16 px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-cursive text-rose-500 mb-4">Some memories for us baby</h2>
        <div className="h-1 w-20 bg-rose-200 mx-auto rounded-full"></div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {MEMORIES.map((memory, index) => (
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            key={memory.id} 
            className="group bg-white rounded-[2.5rem] overflow-hidden shadow-[0_15px_40px_-10px_rgba(0,0,0,0.04)] hover:shadow-[0_30px_60px_-15px_rgba(255,182,193,0.3)] transition-all duration-500"
          >
            <div className="h-72 overflow-hidden relative">
              <img 
                src={memory.imageUrl} 
                alt={memory.caption} 
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </div>
            <div className="p-8">
              <span className="inline-block px-4 py-1 bg-rose-50 text-rose-400 text-sm font-semibold rounded-full mb-3">
                {memory.date}
              </span>
              <p className="text-gray-600 text-xl leading-relaxed font-light italic">
                "{memory.caption}"
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default MemoryGallery;
