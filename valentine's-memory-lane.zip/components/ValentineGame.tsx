
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Props {
  onWin: () => void;
  compliment: string;
  loading: boolean;
}

interface Card {
  id: number;
  emoji: string;
  isFlipped: boolean;
  isMatched: boolean;
}

const EMOJIS = ['❤️', '💖', '🌹', '🎁', '💌', '✨'];

const ValentineGame: React.FC<Props> = ({ onWin, compliment, loading }) => {
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameWon, setGameWon] = useState(false);

  // Initialize and shuffle cards
  const initGame = () => {
    const shuffledCards = [...EMOJIS, ...EMOJIS]
      .sort(() => Math.random() - 0.5)
      .map((emoji, index) => ({
        id: index,
        emoji,
        isFlipped: false,
        isMatched: false,
      }));
    setCards(shuffledCards);
    setFlippedCards([]);
    setGameWon(false);
    setGameStarted(true);
  };

  const handleCardClick = (id: number) => {
    if (flippedCards.length === 2 || cards[id].isFlipped || cards[id].isMatched) return;

    const newCards = [...cards];
    newCards[id].isFlipped = true;
    setCards(newCards);

    const newFlipped = [...flippedCards, id];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      const [firstId, secondId] = newFlipped;
      if (cards[firstId].emoji === cards[secondId].emoji) {
        // Match found
        setTimeout(() => {
          const matchedCards = [...cards];
          matchedCards[firstId].isMatched = true;
          matchedCards[secondId].isMatched = true;
          setCards(matchedCards);
          setFlippedCards([]);

          // Check if all matched
          if (matchedCards.every(card => card.isMatched)) {
            setGameWon(true);
            onWin();
          }
        }, 600);
      } else {
        // No match
        setTimeout(() => {
          const resetCards = [...cards];
          resetCards[firstId].isFlipped = false;
          resetCards[secondId].isFlipped = false;
          setCards(resetCards);
          setFlippedCards([]);
        }, 1000);
      }
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-8">
      {!gameStarted ? (
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-10 text-center rounded-[3rem] shadow-xl"
        >
          <div className="text-6xl mb-6">🧩❤️</div>
          <h2 className="text-3xl font-arabic-romance text-rose-600 mb-6">Pick similar Hearts</h2>
          <p className="text-rose-400 mb-10 text-lg leading-relaxed">
           لازم تطلعي كل اتنين ايموجيز متشابهين مع بعض يروح قلبي
          </p>
          <button 
            onClick={initGame}
            className="bg-rose-500 text-white px-12 py-4 rounded-full text-xl font-bold hover:bg-rose-600 transition-all shadow-lg shadow-rose-200"
          >
            يلا نلعب 
          </button>
        </motion.div>
      ) : gameWon ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-10 md:p-14 rounded-[3.5rem] text-center relative shadow-2xl"
        >
          <motion.div 
            animate={{ scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="text-6xl mb-6"
          >
            👑💖
          </motion.div>
          <h2 className="text-4xl font-arabic-romance text-rose-500 mb-6">شطورة ياحبيبتيييييييييي!</h2>
          <div className="h-px w-32 bg-rose-100 mx-auto mb-8"></div>
          <p className="text-2xl md:text-3xl text-rose-700 italic font-arabic-romance leading-relaxed mb-10 px-4">
            {loading ? "استني المكافئه هتظهر دلوقتي " : `"${compliment}"`}
          </p>
          <button 
            onClick={initGame}
            className="text-rose-400 hover:text-rose-600 transition-colors text-sm font-medium flex items-center justify-center gap-2 mx-auto"
          >
            <span>🔄 العب تاني؟</span>
          </button>
        </motion.div>
      ) : (
        <div className="flex flex-col items-center">
          <div className="mb-8 bg-white/80 px-6 py-2 rounded-full border border-rose-100 shadow-sm text-rose-500 font-bold">
            جمعي كل زوجين متشابهين 
          </div>
          
          <div className="grid grid-cols-3 md:grid-cols-4 gap-4 w-full">
            {cards.map((card) => (
              <div 
                key={card.id} 
                className="relative aspect-square cursor-pointer perspective-1000"
                onClick={() => handleCardClick(card.id)}
              >
                <motion.div
                  className="w-full h-full relative preserve-3d transition-transform duration-500"
                  animate={{ rotateY: card.isFlipped || card.isMatched ? 180 : 0 }}
                >
                  {/* Front of Card (Hidden) */}
                  <div className="absolute inset-0 backface-hidden bg-white/60 glass-card rounded-2xl flex items-center justify-center border-2 border-rose-100 shadow-sm overflow-hidden">
                     <div className="text-rose-200 opacity-40">
                       <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                      </svg>
                     </div>
                  </div>
                  
                  {/* Back of Card (Shown when flipped) */}
                  <div 
                    className="absolute inset-0 backface-hidden bg-white rounded-2xl flex items-center justify-center border-2 border-rose-400 shadow-md transform rotateY-180"
                  >
                    <span className="text-4xl">{card.emoji}</span>
                    {card.isMatched && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="absolute inset-0 bg-rose-500/10 rounded-2xl flex items-center justify-center"
                      >
                         <div className="text-rose-500 absolute top-1 right-1">✓</div>
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              </div>
            ))}
          </div>
          
          <button 
            onClick={initGame}
            className="mt-12 text-rose-400 hover:text-rose-600 underline transition-all text-sm"
          >
            إعادة اللعبة 🔄
          </button>
        </div>
      )}

      <style>{`
        .perspective-1000 { perspective: 1000px; }
        .preserve-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotateY-180 { transform: rotateY(180deg); }
      `}</style>
    </div>
  );
};

export default ValentineGame;
