
import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface Props {
  onAccept: () => void;
}

const ValentineAsk: React.FC<Props> = ({ onAccept }) => {
  const [noButtonPos, setNoButtonPos] = useState({ top: 'auto', left: 'auto' });
  const [yesScale, setYesScale] = useState(1);
  const [noTextIndex, setNoTextIndex] = useState(0);

  const noTexts = [
    "لأ",
    "🤨متأكدة؟",
    "🥺ياحبيبتي",
    "فكري تانييييييي",
    "🥹 يروح قلبي",
    " يلاااااا بقىىىىى"
  ];

  const handleNoHover = () => {
    const randomX = Math.random() * 80;
    const randomY = Math.random() * 80;
    setNoButtonPos({ top: `${randomY}%`, left: `${randomX}%` });
    setYesScale(prev => Math.min(prev + 0.15, 2.5));
    setNoTextIndex(prev => (prev + 1) % noTexts.length);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden bg-[#fff0f3]">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="text-center z-10 bg-white/40 backdrop-blur-xl p-10 md:p-14 rounded-[3rem] shadow-[0_20px_50px_rgba(255,182,193,0.3)] border border-white max-w-xl w-full"
      >
        <img 
          src="https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExbnFxMzFia3VjNm85NXM5MmJrcWZzcmNlcGk5eXoxem9ub2I4eWs3bCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/vX1C2TejT6OCOz2kLd/giphy.gif" 
          alt="Cute Bear"
          className="w-40 h-40 mx-auto mb-8 rounded-2xl grayscale-[0.2] contrast-[1.1]"
        />
        <h1 className="text-4xl md:text-5xl font-cursive text-rose-500 mb-10 leading-tight">
         Can u be my Valentine , Jojo ?
        </h1>
        
        <div className="flex flex-col md:flex-row items-center justify-center gap-8 relative min-h-[140px]">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.9 }}
            onClick={onAccept}
            style={{ transform: `scale(${yesScale})` }}
            className="bg-rose-500 hover:bg-rose-600 text-white font-bold py-4 px-12 rounded-full shadow-lg shadow-rose-200 transition-all z-20"
          >
           YESSSSSS
          </motion.button>

          <button
            onMouseEnter={handleNoHover}
            onClick={handleNoHover}
            className="bg-white/80 text-gray-400 font-medium py-4 px-10 rounded-full border border-pink-100 md:static transition-all duration-500 hover:bg-white"
            style={noButtonPos.top !== 'auto' ? { position: 'absolute', top: noButtonPos.top, left: noButtonPos.left } : {}}
          >
            {noTexts[noTextIndex]}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default ValentineAsk;
