
import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { HeartIcon } from '../constants';

const FloatingHearts: React.FC = () => {
  const hearts = useMemo(() => {
    return Array.from({ length: 18 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: Math.random() * 15,
      duration: 15 + Math.random() * 20,
      scale: 0.5 + Math.random() * 1,
      opacity: 0.1 + Math.random() * 0.3
    }));
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {hearts.map((heart) => (
        <motion.div
          key={heart.id}
          className="absolute bottom-[-10%] text-rose-300"
          initial={{ y: "0%", opacity: 0, x: 0 }}
          animate={{ 
            y: "-1100%", 
            opacity: [0, heart.opacity, heart.opacity, 0],
            x: [0, 50, -50, 0],
            rotate: [0, 45, -45, 0]
          }}
          transition={{
            duration: heart.duration,
            repeat: Infinity,
            delay: heart.delay,
            ease: "linear"
          }}
          style={{
            left: heart.left,
            scale: heart.scale,
          }}
        >
          <HeartIcon className="w-8 h-8 md:w-12 md:h-12" />
        </motion.div>
      ))}
      
      {/* Dynamic soft light flares */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-rose-100/20 blur-[100px] rounded-full animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-peach-100/20 blur-[100px] rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
    </div>
  );
};

export default FloatingHearts;
